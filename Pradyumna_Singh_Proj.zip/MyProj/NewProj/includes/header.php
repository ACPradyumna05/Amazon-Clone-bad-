
    <div class="TopHeader fixed-top">
    <nav class="navbar navbar-expand-lg navbar-custom">
        <a class="navbar-brand" href="frontpage.php">
            <img src="https://www.pngall.com/wp-content/uploads/15/Amazon-Logo-White-Transparent.png" alt="Amazon Logo">
        </a>
        <div class="row mx-auto">
            <div class="pt-1 pr-1">
            <img src="https://static-00.iconduck.com/assets.00/location-icon-1818x2048-9v06myxt.png" height="15px" width="10px"></img>
            </div>
            <div>
            <span class="navbar-text">Delivering to Kanpur</span> <br> <a class="navbar-text-sub" href="#">Update location</a>
    </div>
        </div>
        <div class="row mx-auto w-50">
            <select class="custom-select col-1 rounded-left" style="border-radius: 0;">
                <option selected>All</option>
                <option value="1">Electronics</option>
                <option value="2">Books</option>
                <option value="3">Fashion</option>
            </select>
            <input class="form-control col-10" type="search" placeholder="Search Amazon.in" aria-label="Search">
            
            <button class="btn btn-search col-1 rounded-right" type="submit"><i class="fa fa-solid fa-magnifying-glass"></i></button>
    </div>
        <div class="navbar-text row">
        <label for="lang" class="col-4"><img src="https://upload.wikimedia.org/wikipedia/commons/4/41/Flag_of_India.svg" alt="Indian Flag" style="height: 20px;"></label>
            <select name="lang" id="langselect">
                <option value="1">Eng</option>
                <option value="2">Hindi</option>
                <option value="3">Bengali</option>
                <option value="4">Marathi</option>
                <option value="5">Kanaddh</option>
                <option value="5">Tamil</option>
                <option value="5">Telugu</option>
            </select>
        </div>
        <ul class="navbar-nav">
            <li class="nav-item">
                <button class="w3-button w3-teal w3-xlarge" style="background-color: transparent; box-shadow: 0; border: 0;">
                    <a href="#">Hello, sign in
                        <br>
                    </a>
                    <a href="profilepage.php">
                        Account
                    </a>
                    <a href="Lists.php">
                        Lists
                    </a>
                </button>
            </li>
            <li class="nav-item">
                <a href="Lists.php">Returns<br>& Orders</a>
            </li>
            <li class="nav-item">
                <a href="Lists.php"><i class="fa fa-shopping-cart"></i> Cart</a>
            </li>
        </ul>
    </nav>
    
    </div>
