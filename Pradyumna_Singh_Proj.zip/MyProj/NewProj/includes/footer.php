
    <footer>
        <div class="footer-container">
            <div class="footer-column">
                <h3>Get to Know Us</h3>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Careers</a></li>
                    <li><a href="#">Press Releases</a></li>
                    <li><a href="#">Amazon Science</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3>Connect with Us</h3>
                <ul>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Twitter</a></li>
                    <li><a href="#">Instagram</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3>Make Money with Us</h3>
                <ul>
                    <li><a href="#">Sell on Amazon</a></li>
                    <li><a href="#">Sell under Amazon Accelerator</a></li>
                    <li><a href="#">Protect and Build Your Brand</a></li>
                    <li><a href="#">Amazon Global Selling</a></li>
                    <li><a href="#">Become an Affiliate</a></li>
                    <li><a href="#">Fulfilment by Amazon</a></li>
                    <li><a href="#">Advertise Your Products</a></li>
                    <li><a href="#">Amazon Pay on Merchants</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3>Let Us Help You</h3>
                <ul>
                    <li><a href="#">COVID-19 and Amazon</a></li>
                    <li><a href="#">Your Account</a></li>
                    <li><a href="#">Returns Centre</a></li>
                    <li><a href="#">Recalls and Product Safety Alerts</a></li>
                    <li><a href="#">100% Purchase Protection</a></li>
                    <li><a href="#">Amazon App Download</a></li>
                    <li><a href="#">Help</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="footer-bottom-links">
                <a href="#">AbeBooks<br><span>Books, art & collectibles</span></a>
                <a href="#">Shopbop<br><span>Designer Fashion Brands</span></a>
                <a href="#">Amazon Web Services<br><span>Scalable Cloud Computing Services</span></a>
                <a href="#">Amazon Business<br><span>Everything For Your Business</span></a>
                <a href="#">Audible<br><span>Download Audio Books</span></a>
                <a href="#">Prime Now<br><span>2-Hour Delivery on Everyday Items</span></a>
                <a href="#">IMDb<br><span>Movies, TV & Celebrities</span></a>
                <a href="#">Amazon Prime Music<br><span>100 million songs, ad-free Over 15 million podcast episodes</span></a>
            </div>
            <div class="footer-bottom-country">
                <a href="#">English</a>
                <a href="#">India</a>
            </div>
        </div>
    </footer>

